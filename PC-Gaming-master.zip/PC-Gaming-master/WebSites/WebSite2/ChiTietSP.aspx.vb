﻿
Partial Class ChiTietSP
    Inherits System.Web.UI.Page

End Class
